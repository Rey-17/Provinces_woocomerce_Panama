---------Readme.txt--------

Provincias de la Ciudad de Panamá para envíos en Woocommerce

1. Colocar el archivo .zip en el instalador de pluggins
2. Activar el plugin en el panel de control

3. Agrega las provincias a las cuáles les harás envio.

